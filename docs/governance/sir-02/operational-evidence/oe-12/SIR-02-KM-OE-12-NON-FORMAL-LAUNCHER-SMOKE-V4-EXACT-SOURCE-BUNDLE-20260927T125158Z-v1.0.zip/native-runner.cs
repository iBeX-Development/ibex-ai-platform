using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;

namespace SmokeV4 {
  public sealed class NativeStep {
    public string stage;
    public string api;
    public string utc;
    public bool success;
    public int errorCode;
    public string detail;
    public int syntheticPid;
  }

  public sealed class NativeResult {
    public string stage;
    public string startUtc;
    public string endUtc;
    public long elapsedMilliseconds;
    public string fileName;
    public string processStartInfoArguments;
    public string commandLine;
    public int timeoutMs;
    public bool jobCreated;
    public bool killOnCloseConfigured;
    public bool killOnCloseVerified;
    public int parentPid;
    public int descendantPid;
    public long parentCreationTime;
    public long descendantCreationTime;
    public bool parentAssignedBeforeResume;
    public bool parentInJobBeforeResume;
    public bool descendantInJobBeforeClose;
    public int[] jobPidsBeforeClose;
    public bool parentAliveBeforeClose;
    public bool descendantAliveBeforeClose;
    public bool timeoutDetected;
    public int nativeWaitResult;
    public bool jobClosedForTimeout;
    public bool parentExitedAfterClose;
    public bool descendantExitedAfterClose;
    public uint parentExitCode;
    public uint descendantExitCode;
    public bool parentOriginalPidStillPresent;
    public bool descendantOriginalPidStillPresent;
    public string stdout;
    public string stderr;
    public bool outputTasksCompleted;
    public bool fallbackSafetyCleanupUsed;
    public bool manualSafetyCleanupRequired;
    public string failure;
    public List<NativeStep> steps = new List<NativeStep>();
  }

  public static class NativeRunner {
    const int JobObjectBasicProcessIdList = 3;
    const int JobObjectExtendedLimitInformation = 9;
    const int JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000;
    const int CREATE_SUSPENDED = 0x00000004;
    const int CREATE_NO_WINDOW = 0x08000000;
    const int EXTENDED_STARTUPINFO_PRESENT = 0x00080000;
    const int STARTF_USESTDHANDLES = 0x00000100;
    const int HANDLE_FLAG_INHERIT = 1;
    const int PROC_THREAD_ATTRIBUTE_HANDLE_LIST = 0x00020002;
    const uint WAIT_OBJECT_0 = 0;
    const uint WAIT_TIMEOUT = 0x102;
    const uint WAIT_FAILED = 0xFFFFFFFF;
    const uint STILL_ACTIVE = 259;
    const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
    const uint PROCESS_TERMINATE = 0x0001;
    const uint SYNCHRONIZE = 0x00100000;

    [StructLayout(LayoutKind.Sequential)] struct SECURITY_ATTRIBUTES {
      public int nLength;
      public IntPtr lpSecurityDescriptor;
      [MarshalAs(UnmanagedType.Bool)] public bool bInheritHandle;
    }
    [StructLayout(LayoutKind.Sequential)] struct JOBOBJECT_BASIC_LIMIT_INFORMATION {
      public long PerProcessUserTimeLimit, PerJobUserTimeLimit;
      public int LimitFlags;
      public UIntPtr MinimumWorkingSetSize, MaximumWorkingSetSize;
      public int ActiveProcessLimit;
      public IntPtr Affinity;
      public int PriorityClass, SchedulingClass;
    }
    [StructLayout(LayoutKind.Sequential)] struct IO_COUNTERS {
      public ulong ReadOperationCount, WriteOperationCount, OtherOperationCount;
      public ulong ReadTransferCount, WriteTransferCount, OtherTransferCount;
    }
    [StructLayout(LayoutKind.Sequential)] struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
      public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
      public IO_COUNTERS IoInfo;
      public UIntPtr ProcessMemoryLimit, JobMemoryLimit, PeakProcessMemoryUsed, PeakJobMemoryUsed;
    }
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct STARTUPINFO {
      public int cb;
      public IntPtr lpReserved, lpDesktop, lpTitle;
      public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
      public short wShowWindow, cbReserved2;
      public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError;
    }
    [StructLayout(LayoutKind.Sequential)] struct STARTUPINFOEX {
      public STARTUPINFO StartupInfo;
      public IntPtr lpAttributeList;
    }
    [StructLayout(LayoutKind.Sequential)] struct PROCESS_INFORMATION {
      public IntPtr hProcess, hThread;
      public int dwProcessId, dwThreadId;
    }

    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true, EntryPoint="CreateJobObjectW")]
    static extern IntPtr CreateJobObject(IntPtr attributes, string name);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool SetInformationJobObject(IntPtr job, int infoClass, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION data, int length);
    [DllImport("kernel32.dll", SetLastError=true, EntryPoint="QueryInformationJobObject")]
    static extern bool QueryJobLimit(IntPtr job, int infoClass, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION data, int length, out int returned);
    [DllImport("kernel32.dll", SetLastError=true, EntryPoint="QueryInformationJobObject")]
    static extern bool QueryJobPids(IntPtr job, int infoClass, IntPtr data, int length, out int returned);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool CreatePipe(out IntPtr read, out IntPtr write, ref SECURITY_ATTRIBUTES attributes, int size);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool SetHandleInformation(IntPtr handle, int mask, int flags);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, int flags, ref IntPtr size);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool UpdateProcThreadAttribute(IntPtr list, int flags, IntPtr attribute, IntPtr value, IntPtr size, IntPtr previous, IntPtr returned);
    [DllImport("kernel32.dll")]
    static extern void DeleteProcThreadAttributeList(IntPtr list);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true, EntryPoint="CreateProcessW")]
    static extern bool CreateProcess(string application, StringBuilder commandLine, IntPtr processAttributes, IntPtr threadAttributes,
      [MarshalAs(UnmanagedType.Bool)] bool inherit, int creationFlags, IntPtr environment, string currentDirectory,
      ref STARTUPINFOEX startup, out PROCESS_INFORMATION process);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool IsProcessInJob(IntPtr process, IntPtr job, [MarshalAs(UnmanagedType.Bool)] out bool result);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool GetExitCodeProcess(IntPtr process, out uint code);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool GetProcessTimes(IntPtr process, out long creation, out long exit, out long kernel, out long user);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern IntPtr OpenProcess(uint access, [MarshalAs(UnmanagedType.Bool)] bool inherit, uint pid);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool TerminateProcess(IntPtr process, uint exitCode);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool TerminateJobObject(IntPtr job, uint exitCode);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool CloseHandle(IntPtr handle);

    static bool Valid(IntPtr h) { return h != IntPtr.Zero && h != new IntPtr(-1); }
    static void Step(NativeResult r, string stage, string api, bool success, int code, string detail, int pid) {
      r.steps.Add(new NativeStep { stage=stage, api=api, utc=DateTime.UtcNow.ToString("o"), success=success,
        errorCode=code, detail=detail, syntheticPid=pid });
    }
    static void Require(NativeResult r, string stage, string api, bool success, string detail, int pid) {
      int code = success ? 0 : Marshal.GetLastWin32Error();
      Step(r, stage, api, success, code, detail, pid);
      if (!success) throw new InvalidOperationException(api + " failed at " + stage + "; Win32=" + code);
    }
    static void Close(ref IntPtr handle, NativeResult r, string stage) {
      if (!Valid(handle)) return;
      bool ok = CloseHandle(handle); int err = ok ? 0 : Marshal.GetLastWin32Error();
      Step(r, stage, "CloseHandle", ok, err, "owned handle", 0);
      if (ok) handle = IntPtr.Zero;
    }
    static bool Alive(IntPtr handle) { return Valid(handle) && WaitForSingleObject(handle, 0) == WAIT_TIMEOUT; }
    static long Creation(IntPtr handle) {
      long c,e,k,u;
      if (!GetProcessTimes(handle, out c, out e, out k, out u)) return 0;
      return c;
    }
    static bool OriginalPidStillPresent(int pid, long creation) {
      if (pid <= 0 || creation == 0) return false;
      IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, false, (uint)pid);
      if (!Valid(h)) return false;
      try { return Creation(h) == creation && Alive(h); }
      finally { CloseHandle(h); }
    }
    static int[] ReadJobPids(IntPtr job, NativeResult r, string stage) {
      for (int capacity=8; capacity<=128; capacity*=2) {
        int size = 8 + capacity * IntPtr.Size;
        IntPtr buffer = Marshal.AllocHGlobal(size);
        try {
          int returned;
          bool ok = QueryJobPids(job, JobObjectBasicProcessIdList, buffer, size, out returned);
          int err = ok ? 0 : Marshal.GetLastWin32Error();
          Step(r,stage,"QueryInformationJobObject(JobObjectBasicProcessIdList)",ok,err,"capacity="+capacity+"; returned="+returned,0);
          if (!ok) {
            if (err == 122) continue;
            throw new InvalidOperationException("Job PID query failed; Win32="+err);
          }
          int assigned = Marshal.ReadInt32(buffer,0), inList=Marshal.ReadInt32(buffer,4);
          if (assigned != inList || inList > capacity) continue;
          int[] pids = new int[inList];
          for (int i=0;i<inList;i++) pids[i]=unchecked((int)Marshal.ReadIntPtr(buffer,8+i*IntPtr.Size).ToInt64());
          return pids;
        } finally { Marshal.FreeHGlobal(buffer); }
      }
      throw new InvalidOperationException("Job PID list incomplete or ambiguous");
    }
    static bool ExactPids(int[] actual, int parent, int descendant) {
      if (descendant > 0) return actual.Length == 2 && Array.IndexOf(actual,parent)>=0 && Array.IndexOf(actual,descendant)>=0;
      return actual.Length == 1 && actual[0] == parent;
    }

    public static NativeResult Run(string stage, string executable, string executableQuoted, string arguments,
      string workingDirectory, string pidFile, int timeoutMs) {
      NativeResult r = new NativeResult();
      r.stage=stage; r.startUtc=DateTime.UtcNow.ToString("o"); r.fileName=executable;
      r.processStartInfoArguments=arguments; r.commandLine=executableQuoted+" "+arguments; r.timeoutMs=timeoutMs;
      Stopwatch sw=Stopwatch.StartNew();
      IntPtr job=IntPtr.Zero, inRead=IntPtr.Zero, inWrite=IntPtr.Zero, outRead=IntPtr.Zero,
        outWrite=IntPtr.Zero, errRead=IntPtr.Zero, errWrite=IntPtr.Zero, attrs=IntPtr.Zero,
        handleArray=IntPtr.Zero, descendantHandle=IntPtr.Zero;
      PROCESS_INFORMATION pi=new PROCESS_INFORMATION();
      bool attrsInitialized=false, childCreated=false;
      StreamReader stdoutReader=null, stderrReader=null;
      Task<string> outTask=null, errTask=null;
      try {
        if (String.IsNullOrEmpty(executable) || !File.Exists(executable) || String.IsNullOrEmpty(arguments) ||
            String.IsNullOrEmpty(executableQuoted) || timeoutMs<=0) throw new InvalidOperationException("Pre-launch executable or argument check failed");
        if ((stage=="tree" || stage=="hold") && (String.IsNullOrEmpty(pidFile) || File.Exists(pidFile)))
          throw new InvalidOperationException("Pre-launch synthetic PID path missing or already exists");

        job=CreateJobObject(IntPtr.Zero,null);
        Require(r,stage,"CreateJobObjectW",Valid(job),"anonymous job; non-inheritable handle",0);
        r.jobCreated=true;
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits=new JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
        limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        int limitSize=Marshal.SizeOf(typeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
        Require(r,stage,"SetInformationJobObject",SetInformationJobObject(job,JobObjectExtendedLimitInformation,ref limits,limitSize),
          "JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE; no breakaway",0);
        r.killOnCloseConfigured=true;
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION observed=new JOBOBJECT_EXTENDED_LIMIT_INFORMATION(); int returned;
        bool queryOk=QueryJobLimit(job,JobObjectExtendedLimitInformation,ref observed,limitSize,out returned);
        Require(r,stage,"QueryInformationJobObject(JobObjectExtendedLimitInformation)",queryOk,
          "effectiveFlags="+observed.BasicLimitInformation.LimitFlags+"; returned="+returned,0);
        if ((observed.BasicLimitInformation.LimitFlags & JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE)==0 ||
            (observed.BasicLimitInformation.LimitFlags & 0x00001800)!=0)
          throw new InvalidOperationException("Kill-on-close flag absent or breakaway flag present");
        r.killOnCloseVerified=true;

        SECURITY_ATTRIBUTES sa=new SECURITY_ATTRIBUTES(); sa.nLength=Marshal.SizeOf(typeof(SECURITY_ATTRIBUTES)); sa.bInheritHandle=true;
        Require(r,stage,"CreatePipe(stdin)",CreatePipe(out inRead,out inWrite,ref sa,0),"synthetic release channel",0);
        Require(r,stage,"CreatePipe(stdout)",CreatePipe(out outRead,out outWrite,ref sa,0),"stdout capture",0);
        Require(r,stage,"CreatePipe(stderr)",CreatePipe(out errRead,out errWrite,ref sa,0),"stderr capture",0);
        Require(r,stage,"SetHandleInformation(stdin parent)",SetHandleInformation(inWrite,HANDLE_FLAG_INHERIT,0),"non-inheritable parent end",0);
        Require(r,stage,"SetHandleInformation(stdout parent)",SetHandleInformation(outRead,HANDLE_FLAG_INHERIT,0),"non-inheritable parent end",0);
        Require(r,stage,"SetHandleInformation(stderr parent)",SetHandleInformation(errRead,HANDLE_FLAG_INHERIT,0),"non-inheritable parent end",0);

        IntPtr attrSize=IntPtr.Zero;
        InitializeProcThreadAttributeList(IntPtr.Zero,1,0,ref attrSize);
        if (attrSize.ToInt64()<=0) throw new InvalidOperationException("Attribute-list size query failed; Win32="+Marshal.GetLastWin32Error());
        Step(r,stage,"InitializeProcThreadAttributeList(size)",true,0,"bytes="+attrSize.ToInt64(),0);
        attrs=Marshal.AllocHGlobal(attrSize);
        Require(r,stage,"InitializeProcThreadAttributeList",InitializeProcThreadAttributeList(attrs,1,0,ref attrSize),"one handle-list attribute",0);
        attrsInitialized=true;
        handleArray=Marshal.AllocHGlobal(IntPtr.Size*3);
        Marshal.WriteIntPtr(handleArray,0,inRead); Marshal.WriteIntPtr(handleArray,IntPtr.Size,outWrite);
        Marshal.WriteIntPtr(handleArray,IntPtr.Size*2,errWrite);
        Require(r,stage,"UpdateProcThreadAttribute(HANDLE_LIST)",UpdateProcThreadAttribute(attrs,0,new IntPtr(PROC_THREAD_ATTRIBUTE_HANDLE_LIST),
          handleArray,new IntPtr(IntPtr.Size*3),IntPtr.Zero,IntPtr.Zero),"exactly stdin/stdout/stderr child handles",0);
        STARTUPINFOEX si=new STARTUPINFOEX(); si.StartupInfo.cb=Marshal.SizeOf(typeof(STARTUPINFOEX));
        si.StartupInfo.dwFlags=STARTF_USESTDHANDLES; si.StartupInfo.hStdInput=inRead;
        si.StartupInfo.hStdOutput=outWrite; si.StartupInfo.hStdError=errWrite; si.lpAttributeList=attrs;
        StringBuilder command=new StringBuilder(r.commandLine);
        bool made=CreateProcess(executable,command,IntPtr.Zero,IntPtr.Zero,true,
          CREATE_SUSPENDED|CREATE_NO_WINDOW|EXTENDED_STARTUPINFO_PRESENT,IntPtr.Zero,workingDirectory,ref si,out pi);
        Require(r,stage,"CreateProcessW(CREATE_SUSPENDED)",made,"absolute application and mutable command line",pi.dwProcessId);
        childCreated=true; r.parentPid=pi.dwProcessId; r.parentCreationTime=Creation(pi.hProcess);
        Step(r,stage,"GetProcessTimes(parent)",r.parentCreationTime!=0,r.parentCreationTime!=0?0:Marshal.GetLastWin32Error(),
          "creationTime="+r.parentCreationTime,r.parentPid);
        if (r.parentCreationTime==0) throw new InvalidOperationException("Parent creation time unavailable");
        Close(ref inRead,r,stage); Close(ref outWrite,r,stage); Close(ref errWrite,r,stage);
        Require(r,stage,"AssignProcessToJobObject",AssignProcessToJobObject(job,pi.hProcess),"suspended parent",r.parentPid);
        r.parentAssignedBeforeResume=true;
        bool inJob;
        Require(r,stage,"IsProcessInJob(parent)",IsProcessInJob(pi.hProcess,job,out inJob),"membership query",r.parentPid);
        r.parentInJobBeforeResume=inJob;
        if (!inJob) throw new InvalidOperationException("Parent not in new job before resume");
        stdoutReader=new StreamReader(new FileStream(new SafeFileHandle(outRead,true),FileAccess.Read,4096,false),new UTF8Encoding(false)); outRead=IntPtr.Zero;
        stderrReader=new StreamReader(new FileStream(new SafeFileHandle(errRead,true),FileAccess.Read,4096,false),new UTF8Encoding(false)); errRead=IntPtr.Zero;
        outTask=Task.Run<string>(()=>stdoutReader.ReadToEnd()); errTask=Task.Run<string>(()=>stderrReader.ReadToEnd());
        uint suspendCount=ResumeThread(pi.hThread);
        Require(r,stage,"ResumeThread",suspendCount!=0xFFFFFFFF,"previousSuspendCount="+suspendCount,r.parentPid);
        if (suspendCount!=1) throw new InvalidOperationException("Unexpected prior suspend count="+suspendCount);
        using (FileStream input=new FileStream(new SafeFileHandle(inWrite,true),FileAccess.Write,4096,false)) {
          inWrite=IntPtr.Zero;
          byte[] go=Encoding.ASCII.GetBytes("GO\n"); input.Write(go,0,go.Length); input.Flush();
        }
        Step(r,stage,"synthetic release",true,0,"sent only after verified assignment",r.parentPid);

        if (stage=="tree") {
          Stopwatch ready=Stopwatch.StartNew();
          while (!File.Exists(pidFile) && ready.ElapsedMilliseconds<1100) System.Threading.Thread.Sleep(20);
          if (!File.Exists(pidFile)) throw new InvalidOperationException("Descendant PID signal missing within bound");
          int childPid;
          if (!Int32.TryParse(File.ReadAllText(pidFile).Trim(),out childPid) || childPid<=0 || childPid==r.parentPid)
            throw new InvalidOperationException("Descendant PID signal invalid");
          r.descendantPid=childPid;
          descendantHandle=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_TERMINATE|SYNCHRONIZE,false,(uint)childPid);
          Require(r,stage,"OpenProcess(descendant)",Valid(descendantHandle),"exact synthetic PID",childPid);
          r.descendantCreationTime=Creation(descendantHandle);
          Step(r,stage,"GetProcessTimes(descendant)",r.descendantCreationTime!=0,r.descendantCreationTime!=0?0:Marshal.GetLastWin32Error(),
            "creationTime="+r.descendantCreationTime,childPid);
          if (r.descendantCreationTime==0) throw new InvalidOperationException("Descendant creation time unavailable");
          bool childInJob;
          Require(r,stage,"IsProcessInJob(descendant)",IsProcessInJob(descendantHandle,job,out childInJob),"membership query",childPid);
          r.descendantInJobBeforeClose=childInJob;
          if (!childInJob) throw new InvalidOperationException("Descendant not contained");
        }

        uint wait=WaitForSingleObject(pi.hProcess,(uint)timeoutMs);
        r.nativeWaitResult=unchecked((int)wait);
        Require(r,stage,"WaitForSingleObject(parent)",wait!=WAIT_FAILED,"result="+wait+"; timeoutMs="+timeoutMs,r.parentPid);
        r.timeoutDetected=wait==WAIT_TIMEOUT;
        if (stage=="tree" || stage=="hold") {
          if (wait!=WAIT_TIMEOUT) throw new InvalidOperationException("Expected timeout was not observed");
          r.parentAliveBeforeClose=Alive(pi.hProcess);
          r.descendantAliveBeforeClose=stage=="tree" && Alive(descendantHandle);
          Step(r,stage,"WaitForSingleObject(pre-close liveness)",r.parentAliveBeforeClose &&
            (stage!="tree" || r.descendantAliveBeforeClose),0,"parentAlive="+r.parentAliveBeforeClose+"; descendantAlive="+r.descendantAliveBeforeClose,r.parentPid);
          if (!r.parentAliveBeforeClose || (stage=="tree" && !r.descendantAliveBeforeClose))
            throw new InvalidOperationException("Synthetic parent/descendant not both alive before forced close");
          r.jobPidsBeforeClose=ReadJobPids(job,r,stage);
          if (!ExactPids(r.jobPidsBeforeClose,r.parentPid,r.descendantPid))
            throw new InvalidOperationException("Job PID list contains missing or unrelated process");
          bool closed=CloseHandle(job); int closeErr=closed?0:Marshal.GetLastWin32Error();
          Step(r,stage,"CloseHandle(last job handle)",closed,closeErr,"primary kill-on-close timeout cleanup",r.parentPid);
          if (!closed) throw new InvalidOperationException("Primary job close failed; Win32="+closeErr);
          job=IntPtr.Zero; r.jobClosedForTimeout=true;
          uint parentAfter=WaitForSingleObject(pi.hProcess,3000);
          r.parentExitedAfterClose=parentAfter==WAIT_OBJECT_0;
          Step(r,stage,"WaitForSingleObject(parent post-close)",r.parentExitedAfterClose,parentAfter==WAIT_FAILED?Marshal.GetLastWin32Error():0,
            "result="+parentAfter,r.parentPid);
          if (stage=="tree") {
            uint childAfter=WaitForSingleObject(descendantHandle,3000);
            r.descendantExitedAfterClose=childAfter==WAIT_OBJECT_0;
            Step(r,stage,"WaitForSingleObject(descendant post-close)",r.descendantExitedAfterClose,
              childAfter==WAIT_FAILED?Marshal.GetLastWin32Error():0,"result="+childAfter,r.descendantPid);
          }
          uint parentCode;
          Require(r,stage,"GetExitCodeProcess(parent)",GetExitCodeProcess(pi.hProcess,out parentCode),"post-close",r.parentPid);
          r.parentExitCode=parentCode;
          if (stage=="tree") {
            uint childCode;
            Require(r,stage,"GetExitCodeProcess(descendant)",GetExitCodeProcess(descendantHandle,out childCode),"post-close",r.descendantPid);
            r.descendantExitCode=childCode;
          }
          r.parentOriginalPidStillPresent=OriginalPidStillPresent(r.parentPid,r.parentCreationTime);
          if (stage=="tree") r.descendantOriginalPidStillPresent=OriginalPidStillPresent(r.descendantPid,r.descendantCreationTime);
          Step(r,stage,"post-close original PID verification",!r.parentOriginalPidStillPresent &&
            (stage!="tree" || !r.descendantOriginalPidStillPresent),0,
            "parentPresent="+r.parentOriginalPidStillPresent+"; descendantPresent="+r.descendantOriginalPidStillPresent,r.parentPid);
          if (!r.parentExitedAfterClose || r.parentExitCode==STILL_ACTIVE || r.parentOriginalPidStillPresent ||
              (stage=="tree" && (!r.descendantExitedAfterClose || r.descendantExitCode==STILL_ACTIVE || r.descendantOriginalPidStillPresent)))
            throw new InvalidOperationException("Kill-on-close did not prove full process termination");
        } else {
          if (wait!=WAIT_OBJECT_0) throw new InvalidOperationException("Ordinary child timed out unexpectedly");
          uint code;
          Require(r,stage,"GetExitCodeProcess(parent)",GetExitCodeProcess(pi.hProcess,out code),"ordinary exit",r.parentPid);
          r.parentExitCode=code;
          r.parentExitedAfterClose=true;
          r.jobPidsBeforeClose=ReadJobPids(job,r,stage);
        }

        if (outTask==null || errTask==null || !Task.WaitAll(new Task[]{outTask,errTask},3000))
          throw new InvalidOperationException("Captured output tasks did not finish within bound");
        r.outputTasksCompleted=true; r.stdout=outTask.Result; r.stderr=errTask.Result;
        Step(r,stage,"stdout/stderr capture",true,0,"both streams drained",r.parentPid);
      } catch (Exception ex) {
        r.failure=ex.GetType().Name+": "+ex.Message;
        Step(r,stage,"launcher failure",false,0,r.failure,r.parentPid);
      } finally {
        if (childCreated && Valid(pi.hProcess) && Alive(pi.hProcess)) {
          r.fallbackSafetyCleanupUsed=true;
          if (Valid(job)) {
            bool terminated=TerminateJobObject(job,97);
            Step(r,stage,"TerminateJobObject(safety)",terminated,terminated?0:Marshal.GetLastWin32Error(),"fallback, never PASS",r.parentPid);
          }
          if (Alive(pi.hProcess)) {
            bool terminated=TerminateProcess(pi.hProcess,98);
            Step(r,stage,"TerminateProcess(parent safety)",terminated,terminated?0:Marshal.GetLastWin32Error(),"exact owned process",r.parentPid);
          }
        }
        if (Valid(descendantHandle) && Alive(descendantHandle)) {
          r.fallbackSafetyCleanupUsed=true;
          bool terminated=TerminateProcess(descendantHandle,99);
          Step(r,stage,"TerminateProcess(descendant safety)",terminated,terminated?0:Marshal.GetLastWin32Error(),"exact owned process",r.descendantPid);
        }
        if (Valid(job)) Close(ref job,r,stage);
        if (Valid(pi.hThread)) Close(ref pi.hThread,r,stage);
        if (Valid(pi.hProcess)) {
          if (Alive(pi.hProcess)) r.manualSafetyCleanupRequired=true;
          Close(ref pi.hProcess,r,stage);
        }
        if (Valid(descendantHandle)) {
          if (Alive(descendantHandle)) r.manualSafetyCleanupRequired=true;
          Close(ref descendantHandle,r,stage);
        }
        Close(ref inRead,r,stage); Close(ref inWrite,r,stage); Close(ref outWrite,r,stage);
        Close(ref errWrite,r,stage); Close(ref outRead,r,stage); Close(ref errRead,r,stage);
        if (attrsInitialized) DeleteProcThreadAttributeList(attrs);
        if (Valid(attrs)) Marshal.FreeHGlobal(attrs);
        if (Valid(handleArray)) Marshal.FreeHGlobal(handleArray);
        if (stdoutReader!=null) stdoutReader.Dispose(); if (stderrReader!=null) stderrReader.Dispose();
        sw.Stop(); r.elapsedMilliseconds=sw.ElapsedMilliseconds; r.endUtc=DateTime.UtcNow.ToString("o");
      }
      return r;
    }
  }
}
